import React, { createContext, useContext, useState, useEffect } from 'react';
import type { User, UserProgress } from '@/types';

interface UserContextType {
  user: User | null;
  progress: UserProgress | null;
  isLoggedIn: boolean;
  login: (email: string, _password: string) => Promise<boolean>;
  register: (name: string, email: string, _password: string) => Promise<boolean>;
  logout: () => void;
  updateProgress: (updates: Partial<UserProgress>) => void;
  addLearnedWord: (wordId: string) => void;
  addFavoriteWord: (wordId: string) => void;
  removeFavoriteWord: (wordId: string) => void;
  completeLesson: (lessonId: string) => void;
  updateStudyTime: (minutes: number) => void;
  updateStreak: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [progress, setProgress] = useState<UserProgress | null>(null);

  // Load user from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('linguaplay_user');
    const savedProgress = localStorage.getItem('linguaplay_progress');
    
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    if (savedProgress) {
      setProgress(JSON.parse(savedProgress));
    }
  }, []);

  // Save to localStorage whenever user or progress changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('linguaplay_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('linguaplay_user');
    }
  }, [user]);

  useEffect(() => {
    if (progress) {
      localStorage.setItem('linguaplay_progress', JSON.stringify(progress));
    } else {
      localStorage.removeItem('linguaplay_progress');
    }
  }, [progress]);

  const login = async (email: string, _password: string): Promise<boolean> => {
    // Simulate API call
    const savedUser = localStorage.getItem('linguaplay_user');
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      if (parsedUser.email === email) {
        setUser(parsedUser);
        return true;
      }
    }
    return false;
  };

  const register = async (name: string, email: string, _password: string): Promise<boolean> => {
    // Simulate API call
    const newUser: User = {
      id: Date.now().toString(),
      name,
      email,
      createdAt: new Date(),
    };
    
    const newProgress: UserProgress = {
      userId: newUser.id,
      languageCode: 'en',
      level: 'A1',
      wordsLearned: 0,
      lessonsCompleted: 0,
      testsPassed: 0,
      studyTimeMinutes: 0,
      currentStreak: 0,
      bestStreak: 0,
      lastStudyDate: null,
      completedLessons: [],
      learnedWords: [],
      favoriteWords: [],
    };
    
    setUser(newUser);
    setProgress(newProgress);
    return true;
  };

  const logout = () => {
    setUser(null);
    setProgress(null);
    localStorage.removeItem('linguaplay_user');
    localStorage.removeItem('linguaplay_progress');
  };

  const updateProgress = (updates: Partial<UserProgress>) => {
    if (progress) {
      setProgress({ ...progress, ...updates });
    }
  };

  const addLearnedWord = (wordId: string) => {
    if (progress && !progress.learnedWords.includes(wordId)) {
      setProgress({
        ...progress,
        learnedWords: [...progress.learnedWords, wordId],
        wordsLearned: progress.wordsLearned + 1,
      });
    }
  };

  const addFavoriteWord = (wordId: string) => {
    if (progress && !progress.favoriteWords.includes(wordId)) {
      setProgress({
        ...progress,
        favoriteWords: [...progress.favoriteWords, wordId],
      });
    }
  };

  const removeFavoriteWord = (wordId: string) => {
    if (progress) {
      setProgress({
        ...progress,
        favoriteWords: progress.favoriteWords.filter(id => id !== wordId),
      });
    }
  };

  const completeLesson = (lessonId: string) => {
    if (progress && !progress.completedLessons.includes(lessonId)) {
      setProgress({
        ...progress,
        completedLessons: [...progress.completedLessons, lessonId],
        lessonsCompleted: progress.lessonsCompleted + 1,
      });
    }
  };

  const updateStudyTime = (minutes: number) => {
    if (progress) {
      setProgress({
        ...progress,
        studyTimeMinutes: progress.studyTimeMinutes + minutes,
      });
    }
  };

  const updateStreak = () => {
    if (progress) {
      const today = new Date().toDateString();
      const lastStudy = progress.lastStudyDate ? new Date(progress.lastStudyDate).toDateString() : null;
      
      let newStreak = progress.currentStreak;
      
      if (lastStudy === today) {
        // Already studied today, no change
        return;
      } else if (lastStudy === new Date(Date.now() - 86400000).toDateString()) {
        // Studied yesterday, increment streak
        newStreak += 1;
      } else {
        // Streak broken, reset
        newStreak = 1;
      }
      
      setProgress({
        ...progress,
        currentStreak: newStreak,
        bestStreak: Math.max(newStreak, progress.bestStreak),
        lastStudyDate: new Date(),
      });
    }
  };

  return (
    <UserContext.Provider
      value={{
        user,
        progress,
        isLoggedIn: !!user,
        login,
        register,
        logout,
        updateProgress,
        addLearnedWord,
        addFavoriteWord,
        removeFavoriteWord,
        completeLesson,
        updateStudyTime,
        updateStreak,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};
