import React, { createContext, useContext, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import type { Language, LearningLanguage } from '@/types';
import { uiLanguages, learningLanguages } from '@/data/languages';

interface LanguageContextType {
  // UI Language (website language)
  uiLanguage: Language;
  setUiLanguage: (language: Language) => void;
  
  // Learning Language (language being learned)
  learningLanguage: LearningLanguage | null;
  setLearningLanguage: (language: LearningLanguage | null) => void;
  
  // Available languages
  availableUiLanguages: Language[];
  availableLearningLanguages: LearningLanguage[];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { i18n } = useTranslation();
  
  const [uiLanguage, setUiLanguageState] = useState<Language>(uiLanguages[5]); // Default to English
  const [learningLanguage, setLearningLanguageState] = useState<LearningLanguage | null>(null);

  // Load saved languages from localStorage
  useEffect(() => {
    const savedUiLang = localStorage.getItem('linguaplay_ui_language');
    const savedLearningLang = localStorage.getItem('linguaplay_learning_language');
    
    if (savedUiLang) {
      const lang = uiLanguages.find(l => l.code === savedUiLang);
      if (lang) {
        setUiLanguageState(lang);
        i18n.changeLanguage(lang.code);
      }
    }
    
    if (savedLearningLang) {
      const lang = learningLanguages.find(l => l.code === savedLearningLang);
      if (lang) {
        setLearningLanguageState(lang);
      }
    }
  }, [i18n]);

  const setUiLanguage = (language: Language) => {
    setUiLanguageState(language);
    i18n.changeLanguage(language.code);
    localStorage.setItem('linguaplay_ui_language', language.code);
  };

  const setLearningLanguage = (language: LearningLanguage | null) => {
    setLearningLanguageState(language);
    if (language) {
      localStorage.setItem('linguaplay_learning_language', language.code);
    } else {
      localStorage.removeItem('linguaplay_learning_language');
    }
  };

  return (
    <LanguageContext.Provider
      value={{
        uiLanguage,
        setUiLanguage,
        learningLanguage,
        setLearningLanguage,
        availableUiLanguages: uiLanguages,
        availableLearningLanguages: learningLanguages,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
