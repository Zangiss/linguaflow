import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Brain, Eye, Volume2, Trophy } from 'lucide-react';
import { FadeInOnScroll, StaggerContainer, StaggerItem } from '@/components/animations/FadeIn';

const features = [
  {
    icon: Brain,
    titleKey: 'features.smartTests.title',
    descriptionKey: 'features.smartTests.description',
    color: 'from-[#FF6B6B] to-[#FF8E8E]',
    bgColor: 'bg-[#FF6B6B]/10',
  },
  {
    icon: Eye,
    titleKey: 'features.visual.title',
    descriptionKey: 'features.visual.description',
    color: 'from-[#4ECDC4] to-[#6EE7DE]',
    bgColor: 'bg-[#4ECDC4]/10',
  },
  {
    icon: Volume2,
    titleKey: 'features.pronunciation.title',
    descriptionKey: 'features.pronunciation.description',
    color: 'from-[#FFE66D] to-[#FFF0A0]',
    bgColor: 'bg-[#FFE66D]/20',
  },
  {
    icon: Trophy,
    titleKey: 'features.achievements.title',
    descriptionKey: 'features.achievements.description',
    color: 'from-[#9B59B6] to-[#BB79D6]',
    bgColor: 'bg-[#9B59B6]/10',
  },
];

export const Features = () => {
  const { t } = useTranslation();

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <FadeInOnScroll>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[#2D3436] mb-4">
              {t('features.title')}
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4] mx-auto rounded-full" />
          </div>
        </FadeInOnScroll>

        <StaggerContainer className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <StaggerItem key={index}>
                <motion.div
                  className="relative group"
                  whileHover={{ y: -10 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="bg-white rounded-3xl p-8 shadow-lg border-2 border-gray-100 hover:border-transparent hover:shadow-2xl transition-all duration-300 h-full">
                    {/* Icon */}
                    <div className={`w-16 h-16 rounded-2xl ${feature.bgColor} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center`}>
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                    </div>

                    {/* Content */}
                    <h3 className="text-xl font-bold text-[#2D3436] mb-3">
                      {t(feature.titleKey)}
                    </h3>
                    <p className="text-gray-500 leading-relaxed">
                      {t(feature.descriptionKey)}
                    </p>

                    {/* Hover decoration */}
                    <div className={`absolute -bottom-2 -right-2 w-20 h-20 bg-gradient-to-br ${feature.color} rounded-2xl opacity-0 group-hover:opacity-20 transition-opacity -z-10`} />
                  </div>
                </motion.div>
              </StaggerItem>
            );
          })}
        </StaggerContainer>
      </div>
    </section>
  );
};
