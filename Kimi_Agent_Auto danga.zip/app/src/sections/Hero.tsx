import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { FadeIn, Bounce } from '@/components/animations/FadeIn';

interface HeroProps {
  onStartClick: () => void;
}

export const Hero = ({ onStartClick }: HeroProps) => {
  const { t } = useTranslation();

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-[#FFF9F0] via-white to-[#E8F8F7]">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Floating shapes */}
        <motion.div
          className="absolute top-20 left-10 w-20 h-20 bg-[#FF6B6B]/20 rounded-full"
          animate={{ y: [0, -20, 0], rotate: [0, 180, 360] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute top-40 right-20 w-16 h-16 bg-[#4ECDC4]/20 rounded-xl"
          animate={{ y: [0, 30, 0], rotate: [0, -180, -360] }}
          transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute bottom-40 left-20 w-24 h-24 bg-[#FFE66D]/30 rounded-full"
          animate={{ y: [0, -15, 0], x: [0, 10, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute bottom-20 right-40 w-12 h-12 bg-[#9B59B6]/20 rounded-lg rotate-45"
          animate={{ rotate: [45, 135, 45], scale: [1, 1.2, 1] }}
          transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }}
        />
        
        {/* Stars */}
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute text-[#FFE66D]"
            style={{
              top: `${15 + Math.random() * 70}%`,
              left: `${10 + Math.random() * 80}%`,
            }}
            animate={{ scale: [1, 1.3, 1], opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2 + Math.random() * 2, repeat: Infinity }}
          >
            <Sparkles className="w-4 h-4" />
          </motion.div>
        ))}
      </div>

      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Text content */}
          <div className="flex-1 text-center lg:text-left">
            <FadeIn delay={0}>
              <motion.div
                className="inline-flex items-center gap-2 px-4 py-2 bg-[#FFE66D]/30 rounded-full mb-6"
                whileHover={{ scale: 1.05 }}
              >
                <span className="text-2xl">🎉</span>
                <span className="text-sm font-medium text-[#2D3436]">
                  6 kalbos • 1000+ žodžių
                </span>
              </motion.div>
            </FadeIn>

            <FadeIn delay={0.1}>
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-[#2D3436] mb-6 leading-tight">
                <span className="bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4] bg-clip-text text-transparent">
                  {t('hero.title')}
                </span>
              </h1>
            </FadeIn>

            <FadeIn delay={0.2}>
              <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-xl mx-auto lg:mx-0">
                {t('hero.subtitle')}
              </p>
            </FadeIn>

            <FadeIn delay={0.3}>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button
                  onClick={onStartClick}
                  size="lg"
                  className="bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4] text-white rounded-full px-8 py-6 text-lg font-semibold shadow-lg hover:shadow-xl transition-all hover:scale-105"
                >
                  {t('hero.cta')}
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="rounded-full px-8 py-6 text-lg font-semibold border-2 border-[#4ECDC4] text-[#4ECDC4] hover:bg-[#4ECDC4] hover:text-white transition-all"
                >
                  {t('hero.learnMore')}
                </Button>
              </div>
            </FadeIn>

            {/* Stats */}
            <FadeIn delay={0.4}>
              <div className="flex flex-wrap gap-8 mt-12 justify-center lg:justify-start">
                <div className="text-center">
                  <div className="text-3xl font-bold text-[#FF6B6B]">10K+</div>
                  <div className="text-sm text-gray-500">Mokinių</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-[#4ECDC4]">6</div>
                  <div className="text-sm text-gray-500">Kalbų</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-[#FFE66D]">4.9</div>
                  <div className="text-sm text-gray-500">Įvertinimas</div>
                </div>
              </div>
            </FadeIn>
          </div>

          {/* Mascot/Image */}
          <div className="flex-1 flex justify-center">
            <FadeIn delay={0.2} direction="left">
              <Bounce>
                <div className="relative">
                  {/* Main mascot circle */}
                  <div className="w-72 h-72 md:w-96 md:h-96 bg-gradient-to-br from-[#FF6B6B] via-[#FFE66D] to-[#4ECDC4] rounded-full flex items-center justify-center shadow-2xl">
                    <span className="text-8xl md:text-9xl">🦉</span>
                  </div>
                  
                  {/* Floating elements */}
                  <motion.div
                    className="absolute -top-4 -right-4 bg-white rounded-2xl p-4 shadow-lg"
                    animate={{ y: [0, -10, 0] }}
                    transition={{ duration: 3, repeat: Infinity }}
                  >
                    <span className="text-3xl">📚</span>
                  </motion.div>
                  
                  <motion.div
                    className="absolute -bottom-4 -left-4 bg-white rounded-2xl p-4 shadow-lg"
                    animate={{ y: [0, 10, 0] }}
                    transition={{ duration: 4, repeat: Infinity }}
                  >
                    <span className="text-3xl">🌍</span>
                  </motion.div>
                  
                  <motion.div
                    className="absolute top-1/2 -right-8 bg-white rounded-2xl p-3 shadow-lg"
                    animate={{ x: [0, 10, 0] }}
                    transition={{ duration: 3.5, repeat: Infinity }}
                  >
                    <span className="text-2xl">⭐</span>
                  </motion.div>
                </div>
              </Bounce>
            </FadeIn>
          </div>
        </div>
      </div>

      {/* Wave divider */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M0 120L60 110C120 100 240 80 360 70C480 60 600 60 720 65C840 70 960 80 1080 85C1200 90 1320 90 1380 90L1440 90V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z"
            fill="white"
          />
        </svg>
      </div>
    </section>
  );
};
