import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { FadeInOnScroll, StaggerContainer, StaggerItem } from '@/components/animations/FadeIn';
import { LanguageCard } from '@/components/LanguageCard';
import type { Language, LearningLanguage } from '@/types';

interface LanguageSelectorProps {
  languages: Language[] | LearningLanguage[];
  selectedLanguage: Language | LearningLanguage | null;
  onSelect: (language: Language | LearningLanguage) => void;
  title: string;
  subtitle?: string;
}

export const LanguageSelector = ({
  languages,
  selectedLanguage,
  onSelect,
  title,
  subtitle,
}: LanguageSelectorProps) => {
  const { t } = useTranslation();

  return (
    <section className="py-20 bg-gradient-to-b from-white to-[#FFF9F0]">
      <div className="container mx-auto px-4">
        <FadeInOnScroll>
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-[#2D3436] mb-4">
              {title}
            </h2>
            {subtitle && (
              <p className="text-xl text-gray-500 max-w-2xl mx-auto">
                {subtitle}
              </p>
            )}
            <div className="w-24 h-1 bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4] mx-auto rounded-full mt-4" />
          </div>
        </FadeInOnScroll>

        <StaggerContainer className="flex flex-wrap justify-center gap-6 md:gap-8">
          {languages.map((language, index) => (
            <StaggerItem key={language.code}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <LanguageCard
                  language={language}
                  isSelected={selectedLanguage?.code === language.code}
                  onClick={() => onSelect(language)}
                  size="lg"
                />
              </motion.div>
            </StaggerItem>
          ))}
        </StaggerContainer>

        {/* Selected indicator */}
        {selectedLanguage && (
          <FadeInOnScroll delay={0.3}>
            <div className="mt-12 text-center">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="inline-flex items-center gap-3 px-6 py-3 bg-[#4ECDC4]/10 rounded-full"
              >
                <span className="text-2xl">{selectedLanguage.flagEmoji}</span>
                <span className="font-semibold text-[#4ECDC4]">
                  {t('languages.learningLanguage')}: {selectedLanguage.name}
                </span>
              </motion.div>
            </div>
          </FadeInOnScroll>
        )}
      </div>
    </section>
  );
};
