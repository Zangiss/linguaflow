import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Heart, Mail, Phone, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { FadeInOnScroll } from '@/components/animations/FadeIn';

interface FooterProps {
  onDonateClick?: () => void;
}

export const Footer = ({ onDonateClick }: FooterProps) => {
  const { t } = useTranslation();

  return (
    <footer className="bg-[#2D3436] text-white">
      {/* Donation CTA */}
      <div className="bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4] py-12">
        <div className="container mx-auto px-4 text-center">
          <FadeInOnScroll>
            <h3 className="text-3xl md:text-4xl font-bold mb-4">
              {t('donation.title')}
            </h3>
            <p className="text-lg mb-6 max-w-2xl mx-auto opacity-90">
              {t('donation.description')}
            </p>
            <Button
              onClick={onDonateClick}
              size="lg"
              className="bg-white text-[#FF6B6B] hover:bg-gray-100 rounded-full px-8 py-6 text-lg font-semibold shadow-lg hover:shadow-xl transition-all"
            >
              <Heart className="w-5 h-5 mr-2" />
              {t('donation.button')}
            </Button>
          </FadeInOnScroll>
        </div>
      </div>

      {/* Main footer */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-[#FF6B6B] to-[#4ECDC4] rounded-xl flex items-center justify-center">
                <span className="text-2xl">🦉</span>
              </div>
              <span className="text-2xl font-bold">{t('app.name')}</span>
            </div>
            <p className="text-gray-400 mb-6">
              {t('app.tagline')}
            </p>
            <div className="flex gap-4">
              {['🇱🇹', '🇱🇻', '🇵🇱', '🇳🇱', '🇩🇪', '🇬🇧'].map((flag, i) => (
                <motion.span
                  key={i}
                  className="text-2xl cursor-pointer"
                  whileHover={{ scale: 1.2 }}
                >
                  {flag}
                </motion.span>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">{t('nav.home')}</h4>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  {t('nav.lessons')}
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  {t('nav.tests')}
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  {t('nav.dictionary')}
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  {t('nav.profile')}
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-lg font-semibold mb-6">{t('footer.about')}</h4>
            <ul className="space-y-3">
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  {t('footer.privacy')}
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  {t('footer.terms')}
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  {t('footer.contact')}
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  {t('footer.support')}
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-6">{t('footer.contact')}</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-gray-400">
                <Mail className="w-5 h-5" />
                <span>info@linguaplay.com</span>
              </li>
              <li className="flex items-center gap-3 text-gray-400">
                <Phone className="w-5 h-5" />
                <span>+370 600 00000</span>
              </li>
              <li className="flex items-center gap-3 text-gray-400">
                <MapPin className="w-5 h-5" />
                <span>Vilnius, Lietuva</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-gray-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-400 text-sm">
            {t('footer.copyright')}
          </p>
          <p className="text-gray-400 text-sm flex items-center gap-1">
            Made with <Heart className="w-4 h-4 text-[#FF6B6B] fill-[#FF6B6B]" /> for language learners
          </p>
        </div>
      </div>
    </footer>
  );
};
