import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Globe, ClipboardCheck, BookOpen } from 'lucide-react';
import { FadeInOnScroll } from '@/components/animations/FadeIn';

const steps = [
  {
    number: '1',
    icon: Globe,
    titleKey: 'howItWorks.step1',
    description: 'Pasirink vieną iš 6 kalbų, kurią nori mokytis',
    color: 'bg-[#FF6B6B]',
  },
  {
    number: '2',
    icon: ClipboardCheck,
    titleKey: 'howItWorks.step2',
    description: 'Atlik 10 klausimų testą, kad sužinotume tavo lygį',
    color: 'bg-[#4ECDC4]',
  },
  {
    number: '3',
    icon: BookOpen,
    titleKey: 'howItWorks.step3',
    description: 'Gauk pritaikytas pamokas ir pradėk mokytis!',
    color: 'bg-[#FFE66D]',
  },
];

export const HowItWorks = () => {
  const { t } = useTranslation();

  return (
    <section className="py-20 bg-[#FFF9F0]">
      <div className="container mx-auto px-4">
        <FadeInOnScroll>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[#2D3436] mb-4">
              {t('howItWorks.title')}
            </h2>
            <div className="w-24 h-1 bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4] mx-auto rounded-full" />
          </div>
        </FadeInOnScroll>

        <div className="relative max-w-5xl mx-auto">
          {/* Connecting line */}
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-1 bg-gray-200 -translate-y-1/2 z-0">
            <motion.div
              className="h-full bg-gradient-to-r from-[#FF6B6B] via-[#4ECDC4] to-[#FFE66D]"
              initial={{ width: '0%' }}
              whileInView={{ width: '100%' }}
              viewport={{ once: true }}
              transition={{ duration: 1.5, ease: 'easeInOut' }}
            />
          </div>

          {/* Steps */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <FadeInOnScroll key={index} delay={index * 0.2}>
                  <motion.div
                    className="text-center"
                    whileHover={{ y: -5 }}
                  >
                    <div className="relative inline-block mb-6">
                      {/* Circle background */}
                      <div className={`w-24 h-24 ${step.color} rounded-full flex items-center justify-center shadow-lg mx-auto`}>
                        <Icon className="w-10 h-10 text-white" />
                      </div>
                      
                      {/* Step number badge */}
                      <div className="absolute -top-2 -right-2 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md font-bold text-[#2D3436]">
                        {step.number}
                      </div>

                      {/* Animated dots */}
                      <motion.div
                        className="absolute -bottom-2 left-1/2 -translate-x-1/2 flex gap-1"
                        animate={{ y: [0, 5, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity, delay: index * 0.3 }}
                      >
                        <div className="w-2 h-2 bg-[#FF6B6B] rounded-full" />
                        <div className="w-2 h-2 bg-[#4ECDC4] rounded-full" />
                        <div className="w-2 h-2 bg-[#FFE66D] rounded-full" />
                      </motion.div>
                    </div>

                    <h3 className="text-xl font-bold text-[#2D3436] mb-2">
                      {t(step.titleKey)}
                    </h3>
                    <p className="text-gray-500 max-w-xs mx-auto">
                      {step.description}
                    </p>
                  </motion.div>
                </FadeInOnScroll>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
