import { useState, useCallback } from 'react';

interface UseSpeechReturn {
  speak: (text: string, lang?: string, rate?: number) => void;
  speakLetter: (letter: string, lang?: string) => void;
  stop: () => void;
  isSpeaking: boolean;
  isSupported: boolean;
}

export const useSpeech = (): UseSpeechReturn => {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const isSupported = 'speechSynthesis' in window;

  const speak = useCallback((text: string, lang = 'en-US', rate = 0.8) => {
    if (!isSupported) {
      console.warn('Speech synthesis not supported');
      return;
    }

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = rate;
    utterance.pitch = 1;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  }, [isSupported]);

  const speakLetter = useCallback((letter: string, lang = 'en-US') => {
    if (!isSupported) {
      console.warn('Speech synthesis not supported');
      return;
    }

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(letter);
    utterance.lang = lang;
    utterance.rate = 0.5; // Slower for letters
    utterance.pitch = 1.2;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  }, [isSupported]);

  const stop = useCallback(() => {
    if (isSupported) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, [isSupported]);

  return {
    speak,
    speakLetter,
    stop,
    isSpeaking,
    isSupported,
  };
};

// Language codes mapping
export const languageToSpeechCode: Record<string, string> = {
  en: 'en-US',
  de: 'de-DE',
  nl: 'nl-NL',
  pl: 'pl-PL',
  lt: 'lt-LT',
  lv: 'lv-LV',
};
