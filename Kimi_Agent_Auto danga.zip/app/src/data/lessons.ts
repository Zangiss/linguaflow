import type { Lesson, Word } from '@/types';

// Sample words for English lessons
const englishWords: Word[] = [
  {
    id: 'en-1',
    word: 'Apple',
    translation: 'Obuolys',
    pronunciation: '/ˈæp.əl/',
    example: 'I eat an apple every day.',
    exampleTranslation: 'Aš valgau obuolį kiekvieną dieną.',
    category: 'Food',
  },
  {
    id: 'en-2',
    word: 'Book',
    translation: 'Knyga',
    pronunciation: '/bʊk/',
    example: 'I love reading books.',
    exampleTranslation: 'Aš mėgstu skaityti knygas.',
    category: 'Objects',
  },
  {
    id: 'en-3',
    word: 'Cat',
    translation: 'Katė',
    pronunciation: '/kæt/',
    example: 'The cat is sleeping.',
    exampleTranslation: 'Katė miega.',
    category: 'Animals',
  },
  {
    id: 'en-4',
    word: 'Dog',
    translation: 'Šuo',
    pronunciation: '/dɒɡ/',
    example: 'My dog is very friendly.',
    exampleTranslation: 'Mano šuo labai draugiškas.',
    category: 'Animals',
  },
  {
    id: 'en-5',
    word: 'House',
    translation: 'Namas',
    pronunciation: '/haʊs/',
    example: 'I live in a big house.',
    exampleTranslation: 'Aš gyvenu dideliame name.',
    category: 'Places',
  },
  {
    id: 'en-6',
    word: 'Water',
    translation: 'Vanduo',
    pronunciation: '/ˈwɔː.tər/',
    example: 'Please give me some water.',
    exampleTranslation: 'Prašau duoti man šiek tiek vandens.',
    category: 'Food',
  },
  {
    id: 'en-7',
    word: 'Friend',
    translation: 'Draugas',
    pronunciation: '/frend/',
    example: 'She is my best friend.',
    exampleTranslation: 'Ji yra mano geriausia draugė.',
    category: 'People',
  },
  {
    id: 'en-8',
    word: 'Car',
    translation: 'Automobilis',
    pronunciation: '/kɑːr/',
    example: 'He drives a red car.',
    exampleTranslation: 'Jis vairuoja raudoną automobilį.',
    category: 'Transport',
  },
  {
    id: 'en-9',
    word: 'Sun',
    translation: 'Saulė',
    pronunciation: '/sʌn/',
    example: 'The sun is shining today.',
    exampleTranslation: 'Šiandien šviečia saulė.',
    category: 'Nature',
  },
  {
    id: 'en-10',
    word: 'Tree',
    translation: 'Medis',
    pronunciation: '/triː/',
    example: 'There is a big tree in the garden.',
    exampleTranslation: 'Sode yra didelis medis.',
    category: 'Nature',
  },
];

// Sample lessons
export const lessons: Lesson[] = [
  {
    id: 'en-a1-1',
    languageCode: 'en',
    level: 'A1',
    title: 'Food & Drinks',
    description: 'Learn basic food vocabulary',
    category: 'Food',
    order: 1,
    words: englishWords.filter(w => w.category === 'Food'),
    exercises: [
      {
        id: 'ex-1',
        type: 'multiple-choice',
        question: 'What is "Apple" in Lithuanian?',
        options: ['Obuolys', 'Knyga', 'Katė', 'Šuo'],
        correctAnswer: 'Obuolys',
      },
      {
        id: 'ex-2',
        type: 'fill-blank',
        question: 'I drink _____ every day. (Vanduo)',
        correctAnswer: 'water',
      },
    ],
  },
  {
    id: 'en-a1-2',
    languageCode: 'en',
    level: 'A1',
    title: 'Animals',
    description: 'Learn animal names',
    category: 'Animals',
    order: 2,
    words: englishWords.filter(w => w.category === 'Animals'),
    exercises: [
      {
        id: 'ex-3',
        type: 'multiple-choice',
        question: 'What sound does a cat make?',
        options: ['Woof', 'Meow', 'Moo', 'Quack'],
        correctAnswer: 'Meow',
      },
    ],
  },
  {
    id: 'en-a1-3',
    languageCode: 'en',
    level: 'A1',
    title: 'Nature',
    description: 'Learn nature vocabulary',
    category: 'Nature',
    order: 3,
    words: englishWords.filter(w => w.category === 'Nature'),
    exercises: [],
  },
  {
    id: 'en-a1-4',
    languageCode: 'en',
    level: 'A1',
    title: 'People & Family',
    description: 'Learn about people',
    category: 'People',
    order: 4,
    words: englishWords.filter(w => w.category === 'People'),
    exercises: [],
  },
  {
    id: 'en-a1-5',
    languageCode: 'en',
    level: 'A1',
    title: 'Transport',
    description: 'Learn transport vocabulary',
    category: 'Transport',
    order: 5,
    words: englishWords.filter(w => w.category === 'Transport'),
    exercises: [],
  },
];

// Get lessons by language and level
export const getLessonsByLanguage = (languageCode: string, level?: string): Lesson[] => {
  return lessons.filter(
    lesson => lesson.languageCode === languageCode && (!level || lesson.level === level)
  );
};

// Get lesson by ID
export const getLessonById = (id: string): Lesson | undefined => {
  return lessons.find(lesson => lesson.id === id);
};

// Get words by category
export const getWordsByCategory = (category: string): Word[] => {
  return englishWords.filter(word => word.category === category);
};

// Categories
export const categories = ['Food', 'Animals', 'Nature', 'People', 'Transport', 'Objects', 'Places'];
