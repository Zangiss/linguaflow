import type { Language, LearningLanguage } from '@/types';

// Website UI languages
export const uiLanguages: Language[] = [
  { code: 'lt', name: 'Lietuvių', flag: 'lt', flagEmoji: '🇱🇹' },
  { code: 'lv', name: 'Latviešu', flag: 'lv', flagEmoji: '🇱🇻' },
  { code: 'pl', name: 'Polski', flag: 'pl', flagEmoji: '🇵🇱' },
  { code: 'nl', name: 'Nederlands', flag: 'nl', flagEmoji: '🇳🇱' },
  { code: 'de', name: 'Deutsch', flag: 'de', flagEmoji: '🇩🇪' },
  { code: 'en', name: 'English', flag: 'gb', flagEmoji: '🇬🇧' },
];

// Languages available for learning
export const learningLanguages: LearningLanguage[] = [
  {
    code: 'lt',
    name: 'Lietuvių',
    flagEmoji: '🇱🇹',
    levels: ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'],
  },
  {
    code: 'lv',
    name: 'Latviešu',
    flagEmoji: '🇱🇻',
    levels: ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'],
  },
  {
    code: 'pl',
    name: 'Polski',
    flagEmoji: '🇵🇱',
    levels: ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'],
  },
  {
    code: 'nl',
    name: 'Nederlands',
    flagEmoji: '🇳🇱',
    levels: ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'],
  },
  {
    code: 'de',
    name: 'Deutsch',
    flagEmoji: '🇩🇪',
    levels: ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'],
  },
  {
    code: 'en',
    name: 'English',
    flagEmoji: '🇬🇧',
    levels: ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'],
  },
];

// Get language by code
export const getLanguageByCode = (code: string): Language | undefined => {
  return uiLanguages.find(lang => lang.code === code);
};

export const getLearningLanguageByCode = (code: string): LearningLanguage | undefined => {
  return learningLanguages.find(lang => lang.code === code);
};

// Language names in their native language
export const nativeLanguageNames: Record<string, string> = {
  lt: 'Lietuvių',
  lv: 'Latviešu',
  pl: 'Polski',
  nl: 'Nederlands',
  de: 'Deutsch',
  en: 'English',
};
