import type { Test, Question, LanguageLevel } from '@/types';

// Sample placement test questions for English
const englishPlacementQuestions: Question[] = [
  {
    id: 'q1',
    type: 'multiple-choice',
    question: 'What is the correct translation of "Hello"?',
    options: ['Labas', 'Ačiū', 'Viso gero', 'Prašau'],
    correctAnswer: 'Labas',
    points: 1,
  },
  {
    id: 'q2',
    type: 'multiple-choice',
    question: 'Choose the correct sentence:',
    options: [
      'I am a student',
      'I is a student',
      'I are a student',
      'I be a student',
    ],
    correctAnswer: 'I am a student',
    points: 1,
  },
  {
    id: 'q3',
    type: 'multiple-choice',
    question: 'What is the past tense of "go"?',
    options: ['Goed', 'Went', 'Gone', 'Going'],
    correctAnswer: 'Went',
    points: 2,
  },
  {
    id: 'q4',
    type: 'multiple-choice',
    question: 'Complete: "If I _____ rich, I would buy a house."',
    options: ['am', 'was', 'were', 'be'],
    correctAnswer: 'were',
    points: 3,
  },
  {
    id: 'q5',
    type: 'multiple-choice',
    question: 'What does "ubiquitous" mean?',
    options: [
      'Rare and hard to find',
      'Present everywhere',
      'Very large',
      'Extremely small',
    ],
    correctAnswer: 'Present everywhere',
    points: 3,
  },
  {
    id: 'q6',
    type: 'multiple-choice',
    question: 'Choose the correct phrasal verb: "I need to _____ the meeting."',
    options: ['put off', 'put on', 'put up', 'put in'],
    correctAnswer: 'put off',
    points: 2,
  },
  {
    id: 'q7',
    type: 'multiple-choice',
    question: 'Which sentence uses the subjunctive mood correctly?',
    options: [
      'I wish I was taller',
      'I wish I were taller',
      'I wish I am taller',
      'I wish I be taller',
    ],
    correctAnswer: 'I wish I were taller',
    points: 3,
  },
  {
    id: 'q8',
    type: 'multiple-choice',
    question: 'What is the meaning of "to bite off more than you can chew"?',
    options: [
      'To eat too much food',
      'To take on a task that is too big',
      'To chew food properly',
      'To have dental problems',
    ],
    correctAnswer: 'To take on a task that is too big',
    points: 2,
  },
  {
    id: 'q9',
    type: 'multiple-choice',
    question: 'Complete: "By this time next year, I _____ my degree."',
    options: [
      'will finish',
      'will have finished',
      'am going to finish',
      'finish',
    ],
    correctAnswer: 'will have finished',
    points: 3,
  },
  {
    id: 'q10',
    type: 'multiple-choice',
    question: 'Which word is closest in meaning to "ephemeral"?',
    options: ['Permanent', 'Temporary', 'Eternal', 'Stable'],
    correctAnswer: 'Temporary',
    points: 3,
  },
];

// Dyslexia test questions
const dyslexiaQuestions: Question[] = [
  {
    id: 'd1',
    type: 'multiple-choice',
    question: 'Which letter is this: "b"?',
    options: ['b', 'd', 'p', 'q'],
    correctAnswer: 'b',
    points: 1,
  },
  {
    id: 'd2',
    type: 'multiple-choice',
    question: 'Read this word: "was"',
    options: ['was', 'saw', 'now', 'how'],
    correctAnswer: 'was',
    points: 1,
  },
  {
    id: 'd3',
    type: 'multiple-choice',
    question: 'Which word is spelled correctly?',
    options: ['becuase', 'because', 'becouse', 'beacause'],
    correctAnswer: 'because',
    points: 1,
  },
  {
    id: 'd4',
    type: 'multiple-choice',
    question: 'What do you see: "p" or "q"?',
    options: ['p', 'q', 'b', 'd'],
    correctAnswer: 'p',
    points: 1,
  },
  {
    id: 'd5',
    type: 'multiple-choice',
    question: 'Read this word backwards: "stop"',
    options: ['pots', 'tops', 'spot', 'opts'],
    correctAnswer: 'pots',
    points: 2,
  },
];

// Sample tests
export const tests: Test[] = [
  {
    id: 'placement-en',
    type: 'placement',
    languageCode: 'en',
    title: 'English Level Test',
    description: 'Determine your English proficiency level',
    questions: englishPlacementQuestions,
  },
  {
    id: 'dyslexia-en',
    type: 'dyslexia',
    languageCode: 'en',
    title: 'Dyslexia Screening',
    description: 'Quick screening for reading difficulties',
    questions: dyslexiaQuestions,
  },
];

// Calculate level based on score
export const calculateLevel = (score: number, totalQuestions: number): LanguageLevel => {
  const percentage = (score / totalQuestions) * 100;
  
  if (percentage < 20) return 'A1';
  if (percentage < 40) return 'A2';
  if (percentage < 60) return 'B1';
  if (percentage < 80) return 'B2';
  if (percentage < 90) return 'C1';
  return 'C2';
};

// Get test by ID
export const getTestById = (id: string): Test | undefined => {
  return tests.find(test => test.id === id);
};

// Get tests by language
export const getTestsByLanguage = (languageCode: string): Test[] => {
  return tests.filter(test => test.languageCode === languageCode);
};
