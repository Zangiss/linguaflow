import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, User, BookOpen, Home, ClipboardCheck, Library } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import './i18n';

// Contexts
import { UserProvider, useUser } from '@/context/UserContext';
import { LanguageProvider, useLanguage } from '@/context/LanguageContext';

// Sections
import { Hero } from '@/sections/Hero';
import { Features } from '@/sections/Features';
import { HowItWorks } from '@/sections/HowItWorks';
import { Footer } from '@/sections/Footer';

// Components
import { Button } from '@/components/ui/button';
import { FadeIn } from '@/components/animations/FadeIn';
import { Flashcard } from '@/components/Flashcard';
import { TestQuestion } from '@/components/TestQuestion';
import { GrammarPronunciation } from '@/components/GrammarPronunciation';
import { LanguageCard } from '@/components/LanguageCard';

// Data
import { learningLanguages } from '@/data/languages';
import { lessons } from '@/data/lessons';
import { tests, calculateLevel } from '@/data/tests';

// Types
import type { LearningLanguage } from '@/types';

// Navigation items
const navItems = [
  { path: '/', label: 'nav.home', icon: Home },
  { path: '/lessons', label: 'nav.lessons', icon: BookOpen },
  { path: '/tests', label: 'nav.tests', icon: ClipboardCheck },
  { path: '/dictionary', label: 'nav.dictionary', icon: Library },
  { path: '/profile', label: 'nav.profile', icon: User },
];

// Header Component
const Header = ({ onNavigate }: { onNavigate: (path: string) => void }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { t } = useTranslation();
  const { uiLanguage, setUiLanguage, availableUiLanguages } = useLanguage();
  const { isLoggedIn, user, logout } = useUser();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <motion.button
            onClick={() => onNavigate('/')}
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
          >
            <div className="w-10 h-10 bg-gradient-to-br from-[#FF6B6B] to-[#4ECDC4] rounded-xl flex items-center justify-center">
              <span className="text-xl">🦉</span>
            </div>
            <span className="text-xl font-bold text-[#2D3436] hidden sm:block">
              {t('app.name')}
            </span>
          </motion.button>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <Button
                  key={item.path}
                  variant="ghost"
                  onClick={() => onNavigate(item.path)}
                  className="flex items-center gap-2 text-gray-600 hover:text-[#4ECDC4] hover:bg-[#4ECDC4]/10"
                >
                  <Icon className="w-4 h-4" />
                  {t(item.label)}
                </Button>
              );
            })}
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-2">
            {/* Language selector */}
            <div className="hidden sm:flex items-center gap-1">
              {availableUiLanguages.slice(0, 3).map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => setUiLanguage(lang)}
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm transition-all ${
                    uiLanguage.code === lang.code
                      ? 'bg-[#4ECDC4] text-white'
                      : 'hover:bg-gray-100'
                  }`}
                >
                  {lang.flagEmoji}
                </button>
              ))}
            </div>

            {/* Auth buttons */}
            {isLoggedIn ? (
              <div className="flex items-center gap-2">
                <span className="hidden md:block text-sm text-gray-600">
                  {user?.name}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={logout}
                  className="rounded-full"
                >
                  {t('nav.logout')}
                </Button>
              </div>
            ) : (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigate('/login')}
                className="rounded-full border-[#4ECDC4] text-[#4ECDC4] hover:bg-[#4ECDC4] hover:text-white"
              >
                {t('nav.login')}
              </Button>
            )}

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-white border-t"
          >
            <nav className="container mx-auto px-4 py-4 flex flex-col gap-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Button
                    key={item.path}
                    variant="ghost"
                    onClick={() => {
                      onNavigate(item.path);
                      setIsMenuOpen(false);
                    }}
                    className="justify-start"
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {t(item.label)}
                  </Button>
                );
              })}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

// Landing Page
const LandingPage = ({ onStart }: { onStart: () => void }) => {
  const { t } = useTranslation();
  const { setUiLanguage, availableUiLanguages, uiLanguage } = useLanguage();

  return (
    <div className="pt-16">
      <Hero onStartClick={onStart} />
      <Features />
      
      {/* UI Language Selector */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-[#2D3436] mb-4">
              {t('languages.uiLanguage')}
            </h2>
            <p className="text-gray-500">Pasirink tinklapio kalbą</p>
          </div>
          <div className="flex flex-wrap justify-center gap-6">
            {availableUiLanguages.map((lang) => (
              <LanguageCard
                key={lang.code}
                language={lang}
                isSelected={uiLanguage.code === lang.code}
                onClick={() => setUiLanguage(lang)}
                size="md"
              />
            ))}
          </div>
        </div>
      </section>

      <HowItWorks />
      <Footer />
    </div>
  );
};

// Language Setup Page
const LanguageSetupPage = ({ onComplete }: { onComplete: () => void }) => {
  const [step, setStep] = useState(1);
  const { learningLanguage, setLearningLanguage } = useLanguage();

  const handleLanguageSelect = (lang: LearningLanguage) => {
    setLearningLanguage(lang);
    setStep(2);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF9F0] to-[#E8F8F7] pt-20 pb-10">
      <div className="container mx-auto px-4 max-w-4xl">
        <FadeIn>
          <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12">
            {step === 1 && (
              <>
                <h2 className="text-3xl md:text-4xl font-bold text-[#2D3436] text-center mb-4">
                  Pasirink kalbą mokymuisi
                </h2>
                <p className="text-gray-500 text-center mb-8">
                  Kurią kalbą nori mokytis šiandien?
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                  {learningLanguages.map((lang) => (
                    <motion.button
                      key={lang.code}
                      onClick={() => handleLanguageSelect(lang)}
                      className={`p-6 rounded-2xl border-2 transition-all ${
                        learningLanguage?.code === lang.code
                          ? 'border-[#4ECDC4] bg-[#E8F8F7]'
                          : 'border-gray-200 hover:border-[#FF6B6B]'
                      }`}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <div className="text-5xl mb-3">{lang.flagEmoji}</div>
                      <div className="font-semibold">{lang.name}</div>
                    </motion.button>
                  ))}
                </div>
              </>
            )}

            {step === 2 && learningLanguage && (
              <>
                <h2 className="text-3xl md:text-4xl font-bold text-[#2D3436] text-center mb-4">
                  Pasirinkta kalba: {learningLanguage.flagEmoji} {learningLanguage.name}
                </h2>
                <p className="text-gray-500 text-center mb-8">
                  Dabar atlik lygio nustatymo testą arba pradėk nuo pradžios
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button
                    onClick={onComplete}
                    size="lg"
                    className="bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4] text-white rounded-full px-8"
                  >
                    Atlikti testą
                  </Button>
                  <Button
                    onClick={onComplete}
                    variant="outline"
                    size="lg"
                    className="rounded-full px-8 border-[#4ECDC4]"
                  >
                    Pradėti nuo A1
                  </Button>
                </div>
              </>
            )}
          </div>
        </FadeIn>
      </div>
    </div>
  );
};

// Test Page
const TestPage = () => {
  const { t } = useTranslation();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [isFinished, setIsFinished] = useState(false);

  const test = tests[0]; // Placement test
  const question = test.questions[currentQuestion];

  const handleAnswer = (answer: string) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = answer;
    setAnswers(newAnswers);
    setShowResult(true);

    setTimeout(() => {
      if (currentQuestion < test.questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setShowResult(false);
      } else {
        setIsFinished(true);
      }
    }, 1500);
  };

  const correctCount = answers.filter((a, i) => a === test.questions[i].correctAnswer).length;
  const level = calculateLevel(correctCount, test.questions.length);

  if (isFinished) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FFF9F0] to-[#E8F8F7] pt-20 pb-10">
        <div className="container mx-auto px-4 max-w-2xl">
          <FadeIn>
            <div className="bg-white rounded-3xl shadow-xl p-8 text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="text-6xl mb-4"
              >
                🎉
              </motion.div>
              <h2 className="text-3xl font-bold text-[#2D3436] mb-4">
                {t('tests.placement.result.title')}
              </h2>
              <p className="text-xl mb-4">
                {t('tests.placement.result.score', { correct: correctCount, total: test.questions.length })}
              </p>
              <div className="text-4xl font-bold bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4] bg-clip-text text-transparent mb-6">
                {t('tests.placement.result.level', { level })}
              </div>
              <Button
                onClick={() => window.location.href = '/lessons'}
                size="lg"
                className="bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4] text-white rounded-full px-8"
              >
                {t('tests.placement.result.continue')}
              </Button>
            </div>
          </FadeIn>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF9F0] to-[#E8F8F7] pt-20 pb-10">
      <div className="container mx-auto px-4 max-w-3xl">
        <TestQuestion
          question={question}
          questionNumber={currentQuestion + 1}
          totalQuestions={test.questions.length}
          onAnswer={handleAnswer}
          showResult={showResult}
          isCorrect={answers[currentQuestion] === question.correctAnswer}
        />
      </div>
    </div>
  );
};

// Lessons Page
const LessonsPage = () => {
  const { t } = useTranslation();
  const { learningLanguage } = useLanguage();
  const [selectedLesson, setSelectedLesson] = useState<string | null>(null);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);

  const languageLessons = lessons.filter(
    l => !learningLanguage || l.languageCode === learningLanguage.code
  );

  if (selectedLesson) {
    const lesson = lessons.find(l => l.id === selectedLesson);
    if (!lesson) return null;

    const word = lesson.words[currentWordIndex];

    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FFF9F0] to-[#E8F8F7] pt-20 pb-10">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="flex items-center justify-between mb-6">
            <Button variant="ghost" onClick={() => setSelectedLesson(null)}>
              ← {t('common.back')}
            </Button>
            <span className="text-gray-500">
              {currentWordIndex + 1} / {lesson.words.length}
            </span>
          </div>

          <Flashcard word={word} />

          <div className="flex justify-center gap-4 mt-8">
            <Button
              variant="outline"
              onClick={() => setCurrentWordIndex(Math.max(0, currentWordIndex - 1))}
              disabled={currentWordIndex === 0}
            >
              {t('lessons.flashcard.previous')}
            </Button>
            <Button
              onClick={() => setCurrentWordIndex(Math.min(lesson.words.length - 1, currentWordIndex + 1))}
              disabled={currentWordIndex === lesson.words.length - 1}
              className="bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4] text-white"
            >
              {t('lessons.flashcard.next')}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF9F0] to-[#E8F8F7] pt-20 pb-10">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-[#2D3436] mb-8">{t('lessons.title')}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {languageLessons.map((lesson, index) => (
            <motion.div
              key={lesson.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl p-6 shadow-lg cursor-pointer hover:shadow-xl transition-shadow"
              onClick={() => setSelectedLesson(lesson.id)}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-[#FFE66D] to-[#FF6B6B] rounded-xl flex items-center justify-center text-2xl">
                  {index + 1}
                </div>
                <div>
                  <h3 className="font-bold text-[#2D3436]">{lesson.title}</h3>
                  <p className="text-sm text-gray-500">{lesson.category}</p>
                </div>
              </div>
              <p className="text-gray-600 mb-4">{lesson.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">
                  {t('lessons.words', { count: lesson.words.length })}
                </span>
                <Button size="sm" className="rounded-full bg-[#4ECDC4]">
                  {t('lessons.start')}
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Grammar Page
const GrammarPage = () => {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF9F0] to-[#E8F8F7] pt-20 pb-10">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-[#2D3436] mb-8 text-center">
          {t('grammar.title')}
        </h2>
        <GrammarPronunciation />
      </div>
    </div>
  );
};

// Dictionary Page
const DictionaryPage = () => {
  const { t } = useTranslation();
  const [search, setSearch] = useState('');
  const allWords = lessons.flatMap(l => l.words);
  
  const filteredWords = allWords.filter(w => 
    w.word.toLowerCase().includes(search.toLowerCase()) ||
    w.translation.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF9F0] to-[#E8F8F7] pt-20 pb-10">
      <div className="container mx-auto px-4 max-w-4xl">
        <h2 className="text-3xl font-bold text-[#2D3436] mb-8">{t('dictionary.title')}</h2>
        
        <div className="mb-6">
          <input
            type="text"
            placeholder={t('dictionary.search')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-6 py-4 rounded-2xl border-2 border-gray-200 focus:border-[#4ECDC4] focus:outline-none text-lg"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredWords.map((word, index) => (
            <motion.div
              key={word.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white rounded-2xl p-4 shadow-md flex items-center gap-4"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-[#FFE66D] to-[#FF6B6B] rounded-xl flex items-center justify-center text-2xl">
                📚
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-[#2D3436]">{word.word}</h4>
                <p className="text-gray-500">{word.translation}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Profile Page
const ProfilePage = () => {
  const { t } = useTranslation();
  const { user, progress, isLoggedIn } = useUser();

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FFF9F0] to-[#E8F8F7] pt-20 pb-10">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-[#2D3436] mb-4">
            {t('nav.profile')}
          </h2>
          <p className="text-gray-500 mb-6">Prisijunkite, kad matytumėte savo profilį</p>
          <Button className="bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4] text-white rounded-full px-8">
            {t('nav.login')}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FFF9F0] to-[#E8F8F7] pt-20 pb-10">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="bg-white rounded-3xl shadow-xl p-8 mb-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-20 h-20 bg-gradient-to-br from-[#FF6B6B] to-[#4ECDC4] rounded-full flex items-center justify-center text-4xl">
              {user?.name?.[0] || '👤'}
            </div>
            <div>
              <h2 className="text-2xl font-bold text-[#2D3436]">{user?.name}</h2>
              <p className="text-gray-500">{user?.email}</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-2xl p-4 text-center shadow-md">
            <div className="text-3xl font-bold text-[#FF6B6B]">{progress?.wordsLearned || 0}</div>
            <div className="text-sm text-gray-500">{t('profile.stats.wordsLearned')}</div>
          </div>
          <div className="bg-white rounded-2xl p-4 text-center shadow-md">
            <div className="text-3xl font-bold text-[#4ECDC4]">{progress?.lessonsCompleted || 0}</div>
            <div className="text-sm text-gray-500">{t('profile.stats.lessonsCompleted')}</div>
          </div>
          <div className="bg-white rounded-2xl p-4 text-center shadow-md">
            <div className="text-3xl font-bold text-[#FFE66D]">{progress?.testsPassed || 0}</div>
            <div className="text-sm text-gray-500">{t('profile.stats.testsPassed')}</div>
          </div>
          <div className="bg-white rounded-2xl p-4 text-center shadow-md">
            <div className="text-3xl font-bold text-[#9B59B6]">{progress?.studyTimeMinutes || 0}</div>
            <div className="text-sm text-gray-500">{t('profile.stats.studyTime')}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Main App Component
const AppContent = () => {
  const [currentPage, setCurrentPage] = useState('/');
  const [showLanguageSetup, setShowLanguageSetup] = useState(false);
  const { learningLanguage } = useLanguage();

  const handleStart = () => {
    if (!learningLanguage) {
      setShowLanguageSetup(true);
    } else {
      setCurrentPage('/tests');
    }
  };

  const handleLanguageSetupComplete = () => {
    setShowLanguageSetup(false);
    setCurrentPage('/tests');
  };

  const navigate = (path: string) => {
    setCurrentPage(path);
    window.scrollTo(0, 0);
  };

  // Render current page
  const renderPage = () => {
    if (showLanguageSetup) {
      return <LanguageSetupPage onComplete={handleLanguageSetupComplete} />;
    }

    switch (currentPage) {
      case '/':
        return <LandingPage onStart={handleStart} />;
      case '/lessons':
        return <LessonsPage />;
      case '/tests':
        return <TestPage />;
      case '/grammar':
        return <GrammarPage />;
      case '/dictionary':
        return <DictionaryPage />;
      case '/profile':
        return <ProfilePage />;
      default:
        return <LandingPage onStart={handleStart} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#FFF9F0]">
      <Header onNavigate={navigate} />
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          {renderPage()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

function App() {
  return (
    <UserProvider>
      <LanguageProvider>
        <AppContent />
      </LanguageProvider>
    </UserProvider>
  );
}

export default App;
