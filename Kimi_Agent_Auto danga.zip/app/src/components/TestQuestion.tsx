import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, X, Volume2 } from 'lucide-react';
import type { Question } from '@/types';
import { useSpeech } from '@/hooks/useSpeech';
import { Button } from '@/components/ui/button';
import { useTranslation } from 'react-i18next';

interface TestQuestionProps {
  question: Question;
  questionNumber: number;
  totalQuestions: number;
  onAnswer: (answer: string) => void;
  showResult?: boolean;
  isCorrect?: boolean;
}

export const TestQuestion = ({
  question,
  questionNumber,
  totalQuestions,
  onAnswer,
  showResult = false,
  isCorrect = false,
}: TestQuestionProps) => {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const { speak } = useSpeech();
  const { t } = useTranslation();

  const handleSelect = (answer: string) => {
    if (showResult) return;
    setSelectedAnswer(answer);
    onAnswer(answer);
  };

  const handlePlayQuestion = () => {
    speak(question.question, 'lt-LT');
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      {/* Progress */}
      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-500 mb-2">
          <span>{t('tests.placement.question', { current: questionNumber, total: totalQuestions })}</span>
          <span>{Math.round((questionNumber / totalQuestions) * 100)}%</span>
        </div>
        <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-[#FF6B6B] to-[#4ECDC4]"
            initial={{ width: 0 }}
            animate={{ width: `${(questionNumber / totalQuestions) * 100}%` }}
            transition={{ duration: 0.5 }}
          />
        </div>
      </div>

      {/* Question */}
      <div className="bg-white rounded-3xl shadow-lg p-6 mb-6">
        <div className="flex items-start gap-4">
          <h3 className="text-xl font-semibold text-[#2D3436] flex-1">
            {question.question}
          </h3>
          <Button
            variant="outline"
            size="icon"
            onClick={handlePlayQuestion}
            className="rounded-full w-10 h-10 border-2 border-[#4ECDC4] hover:bg-[#E8F8F7] flex-shrink-0"
          >
            <Volume2 className="w-4 h-4" />
          </Button>
        </div>

        {question.image && (
          <div className="mt-4 flex justify-center">
            <img
              src={question.image}
              alt="Question"
              className="max-h-48 rounded-xl"
            />
          </div>
        )}
      </div>

      {/* Options */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <AnimatePresence>
          {question.options?.map((option, index) => {
            const isSelected = selectedAnswer === option;
            const isCorrectOption = option === question.correctAnswer;
            const showCorrect = showResult && isCorrectOption;
            const showWrong = showResult && isSelected && !isCorrect;

            return (
              <motion.button
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => handleSelect(option)}
                disabled={showResult}
                className={`
                  relative p-4 rounded-2xl text-left font-medium transition-all duration-300
                  ${showCorrect 
                    ? 'bg-green-100 border-2 border-green-500 text-green-800' 
                    : showWrong
                      ? 'bg-red-100 border-2 border-red-500 text-red-800'
                      : isSelected
                        ? 'bg-[#4ECDC4] text-white border-2 border-[#4ECDC4]'
                        : 'bg-white border-2 border-gray-200 hover:border-[#4ECDC4] hover:shadow-md'
                  }
                `}
              >
                <span className="flex items-center justify-between">
                  {option}
                  {showCorrect && <Check className="w-5 h-5 text-green-600" />}
                  {showWrong && <X className="w-5 h-5 text-red-600" />}
                </span>
              </motion.button>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Result message */}
      <AnimatePresence>
        {showResult && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`mt-6 p-4 rounded-2xl text-center font-semibold ${
              isCorrect 
                ? 'bg-green-100 text-green-800' 
                : 'bg-red-100 text-red-800'
            }`}
          >
            {isCorrect ? t('common.correct') : t('common.incorrect')}
            {!isCorrect && (
              <p className="text-sm mt-1 font-normal">
                Teisingas atsakymas: {question.correctAnswer}
              </p>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
