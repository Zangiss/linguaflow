import { useState } from 'react';
import { motion } from 'framer-motion';
import { Volume2, VolumeX } from 'lucide-react';
import { useSpeech } from '@/hooks/useSpeech';
import { languageToSpeechCode } from '@/hooks/useSpeech';
import { useLanguage } from '@/context/LanguageContext';
import { useTranslation } from 'react-i18next';

// Letter sets for different languages
const letterSets: Record<string, string[]> = {
  en: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
  de: ['A', 'Ä', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'Ö', 'P', 'Q', 'R', 'S', 'ß', 'T', 'U', 'Ü', 'V', 'W', 'X', 'Y', 'Z'],
  nl: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
  pl: ['A', 'Ą', 'B', 'C', 'Ć', 'D', 'E', 'Ę', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'Ł', 'M', 'N', 'Ń', 'O', 'Ó', 'P', 'Q', 'R', 'S', 'Ś', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'Ź', 'Ż'],
  lt: ['A', 'Ą', 'B', 'C', 'Č', 'D', 'E', 'Ę', 'Ė', 'F', 'G', 'H', 'I', 'Į', 'Y', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'Š', 'T', 'U', 'Ų', 'Ū', 'V', 'Z', 'Ž'],
  lv: ['A', 'Ā', 'B', 'C', 'Č', 'D', 'E', 'Ē', 'F', 'G', 'Ģ', 'H', 'I', 'Ī', 'J', 'K', 'Ķ', 'L', 'Ļ', 'M', 'N', 'Ņ', 'O', 'P', 'R', 'S', 'Š', 'T', 'U', 'Ū', 'V', 'Z', 'Ž'],
};

export const GrammarPronunciation = () => {
  const [activeLetter, setActiveLetter] = useState<string | null>(null);
  const { speakLetter, isSpeaking, stop } = useSpeech();
  const { learningLanguage } = useLanguage();
  const { t } = useTranslation();

  const letters = learningLanguage ? letterSets[learningLanguage.code] || letterSets.en : letterSets.en;
  const langCode = learningLanguage ? languageToSpeechCode[learningLanguage.code] : 'en-US';

  const handleLetterClick = (letter: string) => {
    if (activeLetter === letter && isSpeaking) {
      stop();
      setActiveLetter(null);
    } else {
      setActiveLetter(letter);
      speakLetter(letter, langCode);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="bg-white rounded-3xl shadow-lg p-6 md:p-8">
        <h3 className="text-2xl font-bold text-[#2D3436] mb-2 text-center">
          {t('grammar.pronunciation.title')}
        </h3>
        <p className="text-gray-500 text-center mb-8">
          {t('grammar.pronunciation.instruction')}
        </p>

        {/* Letters Grid */}
        <div className="grid grid-cols-5 sm:grid-cols-7 md:grid-cols-8 lg:grid-cols-10 gap-3">
          {letters.map((letter, index) => {
            const isActive = activeLetter === letter && isSpeaking;
            
            return (
              <motion.button
                key={letter}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.02 }}
                onClick={() => handleLetterClick(letter)}
                className={`
                  aspect-square rounded-xl font-bold text-lg md:text-xl
                  flex items-center justify-center
                  transition-all duration-300
                  ${isActive
                    ? 'bg-gradient-to-br from-[#FF6B6B] to-[#4ECDC4] text-white shadow-lg scale-110'
                    : 'bg-gray-100 text-[#2D3436] hover:bg-[#4ECDC4] hover:text-white hover:shadow-md'
                  }
                `}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {letter}
                {isActive && (
                  <motion.div
                    className="absolute -top-1 -right-1"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 0.5 }}
                  >
                    <Volume2 className="w-4 h-4 text-white" />
                  </motion.div>
                )}
              </motion.button>
            );
          })}
        </div>

        {/* Stop button */}
        {isSpeaking && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 flex justify-center"
          >
            <button
              onClick={stop}
              className="flex items-center gap-2 px-6 py-3 bg-red-100 text-red-600 rounded-full font-medium hover:bg-red-200 transition-colors"
            >
              <VolumeX className="w-5 h-5" />
              {t('common.cancel')}
            </button>
          </motion.div>
        )}

        {/* Tip */}
        <div className="mt-8 p-4 bg-[#FFE66D]/20 rounded-2xl">
          <p className="text-sm text-gray-600 text-center">
            💡 {t('grammar.pronunciation.repeat')}
          </p>
        </div>
      </div>
    </div>
  );
};
