import { motion } from 'framer-motion';
import type { Language, LearningLanguage } from '@/types';

interface LanguageCardProps {
  language: Language | LearningLanguage;
  isSelected?: boolean;
  onClick: () => void;
  size?: 'sm' | 'md' | 'lg';
}

export const LanguageCard = ({
  language,
  isSelected = false,
  onClick,
  size = 'md',
}: LanguageCardProps) => {
  const sizes = {
    sm: 'w-20 h-20 text-2xl',
    md: 'w-28 h-28 text-4xl',
    lg: 'w-36 h-36 text-5xl',
  };

  const nameSizes = {
    sm: 'text-xs mt-1',
    md: 'text-sm mt-2',
    lg: 'text-base mt-3',
  };

  return (
    <motion.button
      onClick={onClick}
      className="flex flex-col items-center focus:outline-none"
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
    >
      <motion.div
        className={`
          ${sizes[size]}
          rounded-2xl
          flex items-center justify-center
          bg-white
          shadow-lg
          transition-all duration-300
          ${isSelected 
            ? 'ring-4 ring-[#4ECDC4] bg-gradient-to-br from-[#E8F8F7] to-white' 
            : 'hover:ring-2 hover:ring-[#FF6B6B]'
          }
        `}
        animate={isSelected ? { y: -5 } : { y: 0 }}
      >
        <span className="drop-shadow-md">{language.flagEmoji}</span>
      </motion.div>
      <span className={`${nameSizes[size]} font-semibold text-[#2D3436] text-center`}>
        {language.name}
      </span>
    </motion.button>
  );
};
