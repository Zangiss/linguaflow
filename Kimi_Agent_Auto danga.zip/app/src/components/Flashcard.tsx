import { useState } from 'react';
import { motion } from 'framer-motion';
import { Volume2, RotateCw, Check } from 'lucide-react';
import type { Word } from '@/types';
import { useSpeech } from '@/hooks/useSpeech';
import { languageToSpeechCode } from '@/hooks/useSpeech';
import { useLanguage } from '@/context/LanguageContext';
import { Button } from '@/components/ui/button';

interface FlashcardProps {
  word: Word;
  onMarkLearned?: () => void;
  isLearned?: boolean;
}

export const Flashcard = ({ word, onMarkLearned, isLearned = false }: FlashcardProps) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const { speak, isSpeaking } = useSpeech();
  const { learningLanguage } = useLanguage();

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const handlePlayAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    const langCode = learningLanguage ? languageToSpeechCode[learningLanguage.code] : 'en-US';
    speak(isFlipped ? word.translation : word.word, langCode);
  };

  const handleMarkLearned = (e: React.MouseEvent) => {
    e.stopPropagation();
    onMarkLearned?.();
  };

  return (
    <div className="perspective-1000 w-full max-w-sm mx-auto">
      <motion.div
        className="relative w-full h-80 cursor-pointer"
        onClick={handleFlip}
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
        style={{ transformStyle: 'preserve-3d' }}
      >
        {/* Front */}
        <div
          className="absolute inset-0 backface-hidden"
          style={{ backfaceVisibility: 'hidden' }}
        >
          <div className="w-full h-full bg-white rounded-3xl shadow-xl p-6 flex flex-col items-center justify-center border-4 border-[#4ECDC4]">
            {/* Image placeholder */}
            <div className="w-32 h-32 bg-gradient-to-br from-[#FFE66D] to-[#FF6B6B] rounded-2xl flex items-center justify-center mb-4">
              <span className="text-6xl">📚</span>
            </div>
            
            <h3 className="text-3xl font-bold text-[#2D3436] mb-2">{word.word}</h3>
            
            {word.pronunciation && (
              <p className="text-gray-500 text-sm mb-4">{word.pronunciation}</p>
            )}
            
            <div className="flex gap-2 mt-4">
              <Button
                variant="outline"
                size="icon"
                onClick={handlePlayAudio}
                className="rounded-full w-12 h-12 border-2 border-[#4ECDC4] hover:bg-[#E8F8F7]"
              >
                <Volume2 className={`w-5 h-5 ${isSpeaking ? 'animate-pulse' : ''}`} />
              </Button>
              
              <Button
                variant="outline"
                size="icon"
                onClick={handleMarkLearned}
                className={`rounded-full w-12 h-12 border-2 ${
                  isLearned 
                    ? 'border-green-500 bg-green-50' 
                    : 'border-gray-300 hover:border-green-500'
                }`}
              >
                <Check className={`w-5 h-5 ${isLearned ? 'text-green-500' : 'text-gray-400'}`} />
              </Button>
            </div>
            
            <p className="text-xs text-gray-400 mt-4 flex items-center gap-1">
              <RotateCw className="w-3 h-3" />
              Spausk apversti
            </p>
          </div>
        </div>

        {/* Back */}
        <div
          className="absolute inset-0 backface-hidden"
          style={{ 
            backfaceVisibility: 'hidden',
            transform: 'rotateY(180deg)'
          }}
        >
          <div className="w-full h-full bg-gradient-to-br from-[#4ECDC4] to-[#44A08D] rounded-3xl shadow-xl p-6 flex flex-col items-center justify-center text-white">
            <h3 className="text-3xl font-bold mb-2">{word.translation}</h3>
            
            <div className="w-full bg-white/20 rounded-xl p-4 mt-4">
              <p className="text-sm opacity-80 mb-1">Pavyzdys:</p>
              <p className="font-medium">{word.example}</p>
              <p className="text-sm opacity-70 mt-2">{word.exampleTranslation}</p>
            </div>
            
            <Button
              variant="outline"
              size="icon"
              onClick={handlePlayAudio}
              className="rounded-full w-12 h-12 border-2 border-white/50 bg-white/20 hover:bg-white/30 mt-4"
            >
              <Volume2 className={`w-5 h-5 ${isSpeaking ? 'animate-pulse' : ''}`} />
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
