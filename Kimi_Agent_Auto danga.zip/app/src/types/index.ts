// Language types
export interface Language {
  code: string;
  name: string;
  flag: string;
  flagEmoji: string;
}

export interface LearningLanguage {
  code: string;
  name: string;
  flagEmoji: string;
  levels: LanguageLevel[];
}

export type LanguageLevel = 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2';

// User types
export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  createdAt: Date;
}

export interface UserProgress {
  userId: string;
  languageCode: string;
  level: LanguageLevel;
  wordsLearned: number;
  lessonsCompleted: number;
  testsPassed: number;
  studyTimeMinutes: number;
  currentStreak: number;
  bestStreak: number;
  lastStudyDate: Date | null;
  completedLessons: string[];
  learnedWords: string[];
  favoriteWords: string[];
}

// Lesson types
export interface Lesson {
  id: string;
  languageCode: string;
  level: LanguageLevel;
  title: string;
  description: string;
  category: string;
  order: number;
  words: Word[];
  grammar?: GrammarRule[];
  exercises: Exercise[];
}

export interface Word {
  id: string;
  word: string;
  translation: string;
  pronunciation?: string;
  image?: string;
  example: string;
  exampleTranslation: string;
  category: string;
}

export interface GrammarRule {
  id: string;
  title: string;
  explanation: string;
  examples: { original: string; translation: string }[];
}

export interface Exercise {
  id: string;
  type: 'multiple-choice' | 'fill-blank' | 'match' | 'listen';
  question: string;
  options?: string[];
  correctAnswer: string;
  hint?: string;
}

// Test types
export interface Test {
  id: string;
  type: 'placement' | 'progress' | 'dyslexia';
  languageCode: string;
  title: string;
  description: string;
  questions: Question[];
  timeLimit?: number;
}

export interface Question {
  id: string;
  type: 'multiple-choice' | 'listening' | 'writing' | 'speaking' | 'reading';
  question: string;
  image?: string;
  audio?: string;
  options?: string[];
  correctAnswer: string;
  explanation?: string;
  points: number;
}

export interface TestResult {
  testId: string;
  userId: string;
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  level?: LanguageLevel;
  completedAt: Date;
  answers: { questionId: string; answer: string; correct: boolean }[];
}

// Achievement types
export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  condition: string;
  unlockedAt?: Date;
}

// UI types
export interface FlashcardState {
  isFlipped: boolean;
  currentIndex: number;
  words: Word[];
}

export interface NavigationItem {
  label: string;
  path: string;
  icon: string;
}
